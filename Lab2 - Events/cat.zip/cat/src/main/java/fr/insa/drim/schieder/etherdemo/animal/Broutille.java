package fr.insa.drim.schieder.etherdemo.animal;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.RemoteFunctionCall;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 4.5.5.
 */
@SuppressWarnings("rawtypes")
public class Broutille extends Contract {
    private static final String BINARY = "608060405260008054600160a060020a03191633179055610228806100256000396000f3fe608060405234801561001057600080fd5b506004361061005d577c0100000000000000000000000000000000000000000000000000000000600035046301288f3c811461006257806341c0e1b5146100df57806362cfc8a0146100e9575b600080fd5b61006a6100f1565b6040805160208082528351818301528351919283929083019185019080838360005b838110156100a457818101518382015260200161008c565b50505050905090810190601f1680156100d15780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b6100e76101b5565b005b6100e76101f2565b6060600180541015610137575060408051808201909152600b81527f486d6d6d7250757272213f00000000000000000000000000000000000000000060208201526101b2565b6003600154101561017c575060408051808201909152601581527f4d696175486d6d6d72727221203c33203c33203c33000000000000000000000060208201526101b2565b5060408051808201909152600c81527f424555524b212121203a2d58000000000000000000000000000000000000000060208201525b90565b60005473ffffffffffffffffffffffffffffffffffffffff163314156101f05760005473ffffffffffffffffffffffffffffffffffffffff16ff5b565b600180548101905556fea165627a7a72305820450c50682de04d609ef47581e40e13ed2fd3ba14e8faddc3af7f24a9679af3520029";

    public static final String FUNC_CARESS = "caress";

    public static final String FUNC_KILL = "kill";

    public static final String FUNC_OFFERYOGHURT = "offerYoghurt";

    @Deprecated
    protected Broutille(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected Broutille(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    @Deprecated
    protected Broutille(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    protected Broutille(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public RemoteFunctionCall<String> caress() {
        final Function function = new Function(FUNC_CARESS, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteFunctionCall<TransactionReceipt> kill() {
        final Function function = new Function(
                FUNC_KILL, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteFunctionCall<TransactionReceipt> offerYoghurt() {
        final Function function = new Function(
                FUNC_OFFERYOGHURT, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    @Deprecated
    public static Broutille load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new Broutille(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    @Deprecated
    public static Broutille load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new Broutille(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public static Broutille load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new Broutille(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static Broutille load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new Broutille(contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static RemoteCall<Broutille> deploy(Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Broutille.class, web3j, credentials, contractGasProvider, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Broutille> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Broutille.class, web3j, credentials, gasPrice, gasLimit, BINARY, "");
    }

    public static RemoteCall<Broutille> deploy(Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Broutille.class, web3j, transactionManager, contractGasProvider, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Broutille> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Broutille.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, "");
    }
}
